MAVORA — অনলাইন শপ (ডিপ্লয়ের জন্য প্রস্তুত স্টার্টার)
====================================================

এই ZIP-এ MAVORA-এর ওয়েবসাইট, সার্ভার, ডেটাবেস এবং হোস্টিং কনফিগারেশন আছে।

ফিচার:
- বাংলা অনলাইন শপ ও পণ্য ক্যাটালগ
- পণ্য সার্চ ও ক্যাটাগরি
- কাস্টমার রেজিস্ট্রেশন/লগইন
- কার্ট ও ক্যাশ অন ডেলিভারি অর্ডার
- অর্ডার হিস্ট্রি
- অ্যাডমিন প্যানেল: পণ্য যোগ/মুছা, অর্ডার স্ট্যাটাস আপডেট
- পাসওয়ার্ড bcrypt hash করে সংরক্ষণ
- লগইন rate limit, Helmet, session cookie security
- SQLite ডেটাবেস ও session persistent storage
- Render Blueprint ও Docker কনফিগারেশন

গুরুত্বপূর্ণ সীমাবদ্ধতা:
এটি একটি deployable starter project, এখনো অনলাইনে প্রকাশিত নয়। এই সংস্করণে
শুধু Cash on Delivery আছে; bKash/Nagad/card payment যুক্ত নেই। ডেলিভারি
কুরিয়ার, SMS, ইমেইল নোটিফিকেশন, রিটার্ন/রিফান্ড এবং ব্যবসায়িক নীতিমালা আলাদা
করে সেটআপ ও পরীক্ষা করতে হবে।

লোকাল কম্পিউটারে চালানো:
1) ZIP extract করুন।
2) Node.js 20+ ইনস্টল থাকা কম্পিউটারে ফোল্ডার খুলুন।
3) Terminal-এ চালান: npm install
4) .env.example কপি করে .env বানান।
5) SESSION_SECRET-এ কমপক্ষে ৩২ অক্ষরের random secret দিন।
6) নিজের অ্যাডমিন পাসওয়ার্ডের hash তৈরি করুন:
   node -e "require('bcryptjs').hash('নিজের-পাসওয়ার্ড',12).then(console.log)"
   এখানে নিজের পাসওয়ার্ড শুধু নিজের কম্পিউটারে command-এ বসাবেন। ChatGPT-তে পাঠাবেন না।
7) .env-এ ADMIN_EMAIL এবং ADMIN_PASSWORD_HASH বসান।
8) চালান: npm start
9) ব্রাউজারে খুলুন: http://localhost:3000

Render-এ প্রকাশের প্রস্তুতি:
1) GitHub repository তৈরি করে এই ZIP-এর ফাইলগুলো সেখানে upload করতে হবে।
2) Render-এ New > Blueprint নির্বাচন করে repository connect করতে হবে।
3) render.yaml থেকে service তৈরি হবে।
4) Render চাইলে ADMIN_EMAIL ও ADMIN_PASSWORD_HASH নিজের dashboard-এ বসাবেন।
5) SESSION_SECRET Render স্বয়ংক্রিয়ভাবে তৈরি করবে। কোনো secret chat-এ বা public GitHub repository-তে দেবেন না।
6) deploy সফল হলে Render একটি .onrender.com URL দেবে। সেটি খুলে /api/health-এ {"ok":true} দেখা যাচ্ছে কি না যাচাই করুন।

ডেটাবেস সংরক্ষণ:
render.yaml-এ SQLite ডেটা /var/data persistent disk-এ রাখা হয়। Persistent disk
হোস্টিংয়ের paid feature হতে পারে; deploy করার আগে বর্তমান মূল্য ও শর্ত যাচাই করুন।
ডিস্ক/ব্যাকআপ ছাড়া বাস্তব গ্রাহকের অর্ডার নেবেন না।

নিরাপত্তা:
- .env, password, SESSION_SECRET, ADMIN_PASSWORD_HASH কখনো কাউকে পাঠাবেন না।
- ADMIN_PASSWORD_HASH হলো পাসওয়ার্ডের hash; আসল পাসওয়ার্ড নয়।
- Admin account প্রথমবার server start-এ তৈরি হয়। পরে ADMIN_EMAIL বদলালেই পুরোনো admin বদলাবে না।
- ব্যবসা/পেমেন্ট অ্যাকাউন্ট ও hosting billing-এর কাজ অভিভাবকের সহায়তায় করুন।
- গ্রাহকের বাস্তব তথ্য নেওয়ার আগে privacy policy, terms, delivery/return policy তৈরি করুন।
- একজন অভিজ্ঞ ডেভেলপার দিয়ে production security, database backup ও order flow পরীক্ষা করান।

এই প্রকল্প নিজে থেকে কোনো অ্যাকাউন্টে প্রবেশ, পেমেন্ট, ডোমেইন কেনা বা ওয়েবসাইট
প্রকাশ করে না। সেসব ধাপে মালিকের নিজস্ব অনুমোদন প্রয়োজন।
