require("dotenv").config();
const express = require("express");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const dataDir = process.env.DATA_DIR || path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });
if (process.env.NODE_ENV === "production" && (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32)) {
  throw new Error("Production এ SESSION_SECRET কমপক্ষে ৩২ অক্ষরের হতে হবে।");
}
app.set("trust proxy", 1);
const db = new Database(path.join(dataDir, "mavora.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
 email TEXT NOT NULL UNIQUE, phone TEXT, password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'customer', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS products (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, description TEXT DEFAULT '',
 price INTEGER NOT NULL CHECK(price >= 0), category TEXT NOT NULL DEFAULT 'other',
 image_url TEXT DEFAULT '', stock INTEGER NOT NULL DEFAULT 0 CHECK(stock >= 0),
 active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
 customer_name TEXT NOT NULL, phone TEXT NOT NULL, address TEXT NOT NULL,
 payment_method TEXT NOT NULL DEFAULT 'COD', status TEXT NOT NULL DEFAULT 'pending',
 total INTEGER NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS order_items (
 id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL,
 product_id INTEGER NOT NULL, product_name TEXT NOT NULL,
 quantity INTEGER NOT NULL, unit_price INTEGER NOT NULL,
 FOREIGN KEY(order_id) REFERENCES orders(id), FOREIGN KEY(product_id) REFERENCES products(id)
);
`);
const productCount = db.prepare("SELECT COUNT(*) AS n FROM products").get().n;
if (!productCount) {
  const add = db.prepare("INSERT INTO products(name,description,price,category,image_url,stock) VALUES(?,?,?,?,?,?)");
  const seed = [
    ["প্রিমিয়াম কালো টি-শার্ট","আরামদায়ক দৈনন্দিন পোশাক",880,"fashion","",30],
    ["কটন সাদা টি-শার্ট","নরম কটন ফেব্রিক",765,"fashion","",25],
    ["স্মার্ট ওয়াচ","দৈনন্দিন ব্যবহারের স্মার্ট ওয়াচ",1350,"electronics","",15],
    ["ক্যাজুয়াল ব্যাকপ্যাক","স্কুল ও ভ্রমণের ব্যাগ",1125,"bags","",20],
    ["ওয়্যারলেস ইয়ারবাড","ওয়্যারলেস অডিও",1066,"electronics","",18],
    ["স্পোর্টস বোতল","পুনর্ব্যবহারযোগ্য পানির বোতল",450,"home","",40]
  ];
  const tx = db.transaction(rows => rows.forEach(p => add.run(...p)));
  tx(seed);
}
if (process.env.ADMIN_EMAIL && process.env.ADMIN_PASSWORD_HASH) {
  const existing = db.prepare("SELECT id FROM users WHERE email=?").get(process.env.ADMIN_EMAIL.toLowerCase());
  if (!existing) db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'admin')")
    .run(process.env.ADMIN_NAME || "MAVORA Admin", process.env.ADMIN_EMAIL.toLowerCase(), process.env.ADMIN_PASSWORD_HASH);
}

app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "100kb" }));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));
app.use(session({
  store: new SQLiteStore({ db: "sessions.sqlite", dir: dataDir }),
  secret: process.env.SESSION_SECRET || "dev-only-change-this-secret-before-deployment",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 1000*60*60*24*7 }
}));
const authLimiter = rateLimit({ windowMs: 15*60*1000, limit: 20, standardHeaders: true, legacyHeaders: false });
app.use(express.static(path.join(__dirname, "public")));

const clean = (v, max=200) => String(v ?? "").trim().slice(0,max);
const userView = u => ({ id:u.id, name:u.name, email:u.email, role:u.role });
function requireUser(req,res,next){ if(!req.session.userId) return res.status(401).json({error:"প্রথমে লগইন করুন"}); next(); }
function requireAdmin(req,res,next){
  if(!req.session.userId) return res.status(401).json({error:"লগইন প্রয়োজন"});
  const u=db.prepare("SELECT role FROM users WHERE id=?").get(req.session.userId);
  if(!u || u.role!=="admin") return res.status(403).json({error:"অ্যাডমিন অনুমতি প্রয়োজন"});
  next();
}
app.get("/api/health",(req,res)=>res.json({ok:true,store:"MAVORA"}));
app.get("/api/products",(req,res)=>{
  const q=clean(req.query.q,100), category=clean(req.query.category,40);
  let sql="SELECT id,name,description,price,category,image_url,stock FROM products WHERE active=1";
  const args=[];
  if(q){sql+=" AND (name LIKE ? OR description LIKE ?)";args.push(`%${q}%`,`%${q}%`);}
  if(category && category!=="all"){sql+=" AND category=?";args.push(category);}
  sql+=" ORDER BY id DESC";
  res.json(db.prepare(sql).all(...args));
});
app.get("/api/me",(req,res)=>{
  if(!req.session.userId) return res.json({user:null});
  const u=db.prepare("SELECT id,name,email,role FROM users WHERE id=?").get(req.session.userId);
  res.json({user:u||null});
});
app.post("/api/register",authLimiter,async(req,res)=>{
  const name=clean(req.body.name,80), email=clean(req.body.email,160).toLowerCase();
  const phone=clean(req.body.phone,20), password=String(req.body.password||"");
  if(name.length<2 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length<10)
    return res.status(400).json({error:"নাম, সঠিক ইমেইল এবং কমপক্ষে ১০ অক্ষরের পাসওয়ার্ড দিন"});
  try{
    const hash=await bcrypt.hash(password,12);
    const info=db.prepare("INSERT INTO users(name,email,phone,password_hash) VALUES(?,?,?,?)").run(name,email,phone,hash);
    req.session.userId=info.lastInsertRowid;
    res.json({user:{id:info.lastInsertRowid,name,email,role:"customer"}});
  }catch(e){res.status(409).json({error:"এই ইমেইল দিয়ে আগে অ্যাকাউন্ট খোলা হয়েছে"});}
});
app.post("/api/login",authLimiter,async(req,res)=>{
  const email=clean(req.body.email,160).toLowerCase(), password=String(req.body.password||"");
  const u=db.prepare("SELECT * FROM users WHERE email=?").get(email);
  if(!u || !(await bcrypt.compare(password,u.password_hash))) return res.status(401).json({error:"ইমেইল অথবা পাসওয়ার্ড সঠিক নয়"});
  req.session.regenerate(err=>{
    if(err) return res.status(500).json({error:"লগইন করা যায়নি"});
    req.session.userId=u.id; res.json({user:userView(u)});
  });
});
app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/orders",requireUser,(req,res)=>{
  const orders=db.prepare("SELECT * FROM orders WHERE user_id=? ORDER BY id DESC").all(req.session.userId);
  const items=db.prepare("SELECT product_name,quantity,unit_price FROM order_items WHERE order_id=?");
  res.json(orders.map(o=>({...o,items:items.all(o.id)})));
});
app.post("/api/orders",requireUser,(req,res)=>{
  const customer_name=clean(req.body.name,80),phone=clean(req.body.phone,20),address=clean(req.body.address,500);
  const items=Array.isArray(req.body.items)?req.body.items:[];
  if(customer_name.length<2 || !/^01[0-9]{9}$/.test(phone) || address.length<8 || !items.length)
    return res.status(400).json({error:"নাম, ১১ সংখ্যার মোবাইল, ঠিকানা ও পণ্য দিন"});
  if(items.length>30) return res.status(400).json({error:"একসঙ্গে সর্বোচ্চ ৩০ ধরনের পণ্য অর্ডার করা যাবে"});
  try{
    const create=db.transaction(()=>{
      let total=0, normalized=[];
      for(const it of items){
        const id=Number(it.productId), qty=Number(it.quantity);
        if(!Number.isInteger(id)||!Number.isInteger(qty)||qty<1||qty>20) throw new Error("পণ্যের পরিমাণ সঠিক নয়");
        const p=db.prepare("SELECT id,name,price,stock FROM products WHERE id=? AND active=1").get(id);
        if(!p || p.stock<qty) throw new Error("কোনো পণ্যের স্টক পর্যাপ্ত নেই: "+(p?.name||"পণ্য"));
        total+=p.price*qty; normalized.push({...p,qty});
      }
      const order=db.prepare("INSERT INTO orders(user_id,customer_name,phone,address,payment_method,total) VALUES(?,?,?,?, 'COD', ?)")
        .run(req.session.userId,customer_name,phone,address,total);
      for(const p of normalized){
        db.prepare("INSERT INTO order_items(order_id,product_id,product_name,quantity,unit_price) VALUES(?,?,?,?,?)").run(order.lastInsertRowid,p.id,p.name,p.qty,p.price);
        db.prepare("UPDATE products SET stock=stock-? WHERE id=?").run(p.qty,p.id);
      }
      return {id:order.lastInsertRowid,total};
    });
    res.status(201).json(create());
  }catch(e){res.status(400).json({error:e.message||"অর্ডার করা যায়নি"});}
});
app.get("/api/admin/orders",requireAdmin,(req,res)=>{
  res.json(db.prepare("SELECT id,customer_name,phone,address,status,total,created_at FROM orders ORDER BY id DESC").all());
});
app.patch("/api/admin/orders/:id",requireAdmin,(req,res)=>{
  const status=clean(req.body.status,30);
  if(!["pending","confirmed","shipped","delivered","cancelled"].includes(status)) return res.status(400).json({error:"অবস্থা সঠিক নয়"});
  const info=db.prepare("UPDATE orders SET status=? WHERE id=?").run(status,Number(req.params.id));
  res.json({updated:info.changes});
});
app.post("/api/admin/products",requireAdmin,(req,res)=>{
  const name=clean(req.body.name,120),description=clean(req.body.description,500),category=clean(req.body.category,40);
  const price=Number(req.body.price),stock=Number(req.body.stock),image_url=clean(req.body.image_url,500);
  if(name.length<2||!Number.isInteger(price)||price<1||!Number.isInteger(stock)||stock<0) return res.status(400).json({error:"পণ্যের নাম, সঠিক দাম ও স্টক দিন"});
  const info=db.prepare("INSERT INTO products(name,description,price,category,image_url,stock) VALUES(?,?,?,?,?,?)").run(name,description,price,category,image_url,stock);
  res.status(201).json({id:info.lastInsertRowid});
});
app.patch("/api/admin/products/:id",requireAdmin,(req,res)=>{
  const p=db.prepare("SELECT * FROM products WHERE id=?").get(Number(req.params.id));
  if(!p)return res.status(404).json({error:"পণ্য পাওয়া যায়নি"});
  const name=clean(req.body.name??p.name,120),price=Number(req.body.price??p.price),stock=Number(req.body.stock??p.stock);
  if(!name||!Number.isInteger(price)||price<1||!Number.isInteger(stock)||stock<0)return res.status(400).json({error:"তথ্য সঠিক নয়"});
  db.prepare("UPDATE products SET name=?,price=?,stock=? WHERE id=?").run(name,price,stock,p.id);
  res.json({ok:true});
});
app.delete("/api/admin/products/:id",requireAdmin,(req,res)=>{
  db.prepare("UPDATE products SET active=0 WHERE id=?").run(Number(req.params.id));res.json({ok:true});
});
app.use((err,req,res,next)=>{console.error(err);res.status(500).json({error:"সার্ভারে সমস্যা হয়েছে"});});
app.listen(PORT,()=>console.log(`MAVORA running at http://localhost:${PORT}`));
